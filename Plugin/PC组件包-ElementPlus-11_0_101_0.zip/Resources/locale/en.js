﻿
(() => {
    if (!Forguncy.Plugin.LocalizationResource) {
        Forguncy.Plugin.LocalizationResource = {}
    }
    if (Forguncy.Plugin.LocalizationResource[`2CCB2F02-D923-491E-94E4-72C9BD8C5ABE`]) {
        Forguncy.Plugin.LocalizationResource[`2CCB2F02-D923-491E-94E4-72C9BD8C5ABE`] = {
            ...Forguncy.Plugin.LocalizationResource[`2CCB2F02-D923-491E-94E4-72C9BD8C5ABE`],
            ...{"CellValue":"Cell value","PagingInfo":"Paging Information"}
        };
    } else {
        Forguncy.Plugin.LocalizationResource[`2CCB2F02-D923-491E-94E4-72C9BD8C5ABE`] = {"CellValue":"Cell value","PagingInfo":"Paging Information"};
    }
})();
